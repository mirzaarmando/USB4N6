
from __future__ import annotations
import json
from datetime import datetime
from typing import Any

def json_safe(obj: Any) -> Any:
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, (list, tuple)):
        return [json_safe(x) for x in obj]
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    return str(obj)

def dumps(obj: Any, **kwargs) -> str:
    return json.dumps(json_safe(obj), ensure_ascii=False, **kwargs)


import os
import sys
import subprocess
from pathlib import Path

def is_windows() -> bool:
    return os.name == "nt"

def is_windows_admin() -> bool:
    """Return True if current process has admin privileges on Windows."""
    if not is_windows():
        return False
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False

def run_cmd(cmd, cwd=None, timeout=120):
    """Run command and return (rc, stdout, stderr) with safe text decoding."""
    p = subprocess.run(
        cmd,
        cwd=cwd,
        timeout=timeout,
        capture_output=True,
        text=True,
        shell=False,
        encoding="utf-8",
        errors="replace",
    )
    return p.returncode, p.stdout, p.stderr

def auto_collect_usb_artifacts(out_dir: str):
    """
    Auto-collect USB artifacts on Windows into out_dir.
    Produces:
    - usbstor.reg
    - MountedDevices.reg
    - system_usb.xml (filtered System log events)
    - setupapi.dev.log (if exists)
    Returns dict of file paths.
    """
    outp = Path(out_dir)
    outp.mkdir(parents=True, exist_ok=True)

    paths = {}

    # 1) Registry exports
    usbstor = outp / "usbstor.reg"
    mounted = outp / "MountedDevices.reg"

    rc, so, se = run_cmd(["reg", "export", r"HKLM\SYSTEM\CurrentControlSet\Enum\USBSTOR", str(usbstor), "/y"], timeout=120)
    paths["usbstor_reg"] = str(usbstor)
    paths["usbstor_reg_rc"] = rc
    paths["usbstor_reg_err"] = se

    rc2, so2, se2 = run_cmd(["reg", "export", r"HKLM\SYSTEM\MountedDevices", str(mounted), "/y"], timeout=120)
    paths["mounted_reg"] = str(mounted)
    paths["mounted_reg_rc"] = rc2
    paths["mounted_reg_err"] = se2

    # 2) System event log (filtered) → XML
    sysxml = outp / "system_usb.xml"
    # Filter for UserPnp/Kernel-PnP and key event IDs
    query = "*[System[(Provider[@Name='Microsoft-Windows-UserPnp'] or Provider[@Name='Microsoft-Windows-Kernel-PnP']) and (EventID=20001 or EventID=20003 or EventID=400 or EventID=410 or EventID=411)]]"
    # Use wevtutil to query and format xml
    # Note: wevtutil prints XML stream; we wrap it into an Events root for easier parsing.
    rc3, so3, se3 = run_cmd(["wevtutil", "qe", "System", f"/q:{query}", "/f:xml"], timeout=180)
    paths["system_xml"] = str(sysxml)
    paths["system_xml_rc"] = rc3
    paths["system_xml_err"] = se3
    if rc3 == 0 and so3.strip():
        sysxml.write_text("<Events>\n" + so3 + "\n</Events>\n", encoding="utf-8", errors="ignore")
    else:
        # create empty placeholder
        sysxml.write_text("<Events></Events>", encoding="utf-8")

    # 3) setupapi.dev.log (optional)
    setupapi = Path(r"C:\Windows\INF\setupapi.dev.log")
    if setupapi.exists():
        dst = outp / "setupapi.dev.log"
        try:
            dst.write_bytes(setupapi.read_bytes())
            paths["setupapi_log"] = str(dst)
        except Exception as e:
            paths["setupapi_log_err"] = str(e)

    return paths


import tempfile

def evtx_bytes_to_xml_bytes(evtx_bytes: bytes) -> bytes:
    """
    Convert .evtx bytes to XML bytes using wevtutil (Windows only).
    This avoids external Python EVTX dependencies.
    """
    if not is_windows():
        raise RuntimeError("Konversi EVTX hanya tersedia di Windows. Export log sebagai XML lalu upload XML.")
    with tempfile.TemporaryDirectory() as td:
        evtx_path = Path(td) / "log.evtx"
        evtx_path.write_bytes(evtx_bytes)
        # /lf:true => query from log file, not from live log name
        rc, so, se = run_cmd(["wevtutil", "qe", str(evtx_path), "/lf:true", "/f:xml"], timeout=180)
        if rc != 0:
            raise RuntimeError(f"wevtutil gagal (rc={rc}). {se.strip()[:400]}")
        xml = "<Events>\n" + (so or "") + "\n</Events>\n"
        return xml.encode("utf-8", errors="ignore")
