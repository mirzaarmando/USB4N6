
from __future__ import annotations
import re
import html
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Tuple
from datetime import datetime

# pandas is an explicit dependency of this project (see requirements.txt)
# and is used for resilient datetime parsing.
import pandas as pd

@dataclass
class USBDevice:
    device_id: str
    instance_id: str
    vendor: Optional[str] = None
    product: Optional[str] = None
    revision: Optional[str] = None
    friendly_name: Optional[str] = None
    hardware_id: Optional[str] = None
    class_guid: Optional[str] = None
    container_id: Optional[str] = None
    first_seen: Optional[datetime] = None
    drive_letters: Optional[List[str]] = None
    evidence: Optional[Dict[str, str]] = None

    def to_dict(self):
        d = asdict(self)
        if self.first_seen:
            d["first_seen"] = self.first_seen.isoformat(sep=" ")
        return d

def parse_reg_export_usbstor(text: str) -> List[USBDevice]:
    devices: Dict[Tuple[str, str], USBDevice] = {}

    key_re = re.compile(r'^\[(HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Enum\\USBSTOR\\([^\\\]]+)\\([^\\\]]+))\]\s*$', re.I)
    val_re = re.compile(r'^"([^"]+)"=(.*)$')

    current_dev_key = None
    current_instance = None
    current_key_full = None

    for line in text.splitlines():
        s = line.strip()
        km = key_re.match(s)
        if km:
            current_key_full = km.group(1)
            current_dev_key = km.group(2)
            current_instance = km.group(3)
            k = (current_dev_key, current_instance)
            if k not in devices:
                devices[k] = USBDevice(
                    device_id=f"USBSTOR\\{current_dev_key}",
                    instance_id=current_instance,
                    evidence={"reg_key": current_key_full},
                    drive_letters=[],
                )
            continue

        if current_dev_key and current_instance:
            vm = val_re.match(s)
            if not vm:
                continue
            name = vm.group(1)
            rhs = vm.group(2).strip()

            def _parse_reg_sz(v: str) -> Optional[str]:
                if v.startswith('"') and v.endswith('"'):
                    return v[1:-1]
                return None

            value = _parse_reg_sz(rhs)
            dev = devices[(current_dev_key, current_instance)]

            if name.lower() == "friendlyname" and value:
                dev.friendly_name = value
            elif name.lower() == "classguid" and value:
                dev.class_guid = value
            elif name.lower() == "containerid" and value:
                dev.container_id = value
            elif name.lower() == "hardwareid" and value:
                dev.hardware_id = value

            dev.evidence = dev.evidence or {}
            if len(dev.evidence) < 10:
                dev.evidence[f"reg_value:{name}"] = rhs[:220]

    for dev in devices.values():
        s = dev.device_id
        m = re.search(r'Ven_([^&]+)', s, re.I)
        if m: dev.vendor = m.group(1).replace('_',' ')
        m = re.search(r'Prod_([^&]+)', s, re.I)
        if m: dev.product = m.group(1).replace('_',' ')
        m = re.search(r'Rev_([^\\]+)$', s, re.I)
        if m: dev.revision = m.group(1).replace('_',' ')
    return list(devices.values())

def _reg_join_continuations(text: str) -> List[str]:
    """
    Regedit export may wrap long hex values using a trailing backslash and continuation lines.
    This function joins those wrapped lines into single logical lines.
    """
    out: List[str] = []
    buf = ""
    for raw in text.splitlines():
        line = raw.rstrip("\n")
        if buf:
            line2 = line.lstrip()
            buf += line2
        else:
            buf = line
        if buf.endswith("\\"):
            buf = buf[:-1]
            continue
        out.append(buf)
        buf = ""
    if buf:
        out.append(buf)
    return out

def parse_reg_export_mounteddevices_entries(text: str) -> List[Dict[str, str]]:
    """
    Parse HKLM\\SYSTEM\\MountedDevices export and return *all* values for transparency.

    Returns list of dicts:
      - name: value name (e.g. \\DosDevices\\E: or \\??\\Volume{...})
      - kind: DriveLetter / VolumeGUID / Other
      - drive_letter: E: (if DriveLetter)
      - decoded_hint: best-effort utf-16 decode from binary, else short hex snippet
      - raw: RHS value (truncated)
    """
    section_re = re.compile(r'^\[HKEY_LOCAL_MACHINE\\SYSTEM\\MountedDevices\]\s*$', re.I)
    val_re = re.compile(r'^"([^"]+)"=(.*)$')
    hex_re = re.compile(r'^hex(?:\([0-9a-f]+\))?:', re.I)

    in_section = False
    entries: List[Dict[str, str]] = []

    lines = _reg_join_continuations(text)

    def _looks_garbled(s: str) -> bool:
        if not s:
            return True
        # If too many replacement chars or non-printables, treat as garbled.
        rep = s.count("\ufffd")
        if rep >= 2:
            return True
        printable = sum(1 for ch in s if ch.isprintable())
        ratio = printable / max(1, len(s))
        return ratio < 0.80

    def _decode_rhs(rhs: str) -> str:
        if not rhs:
            return ""
        if hex_re.match(rhs):
            try:
                hex_part = rhs.split(":", 1)[1]
                hex_part = hex_part.replace("\\", "")
                hex_bytes = bytes(int(x, 16) for x in hex_part.split(",") if x.strip())
                decoded = hex_bytes.decode("utf-16-le", errors="ignore")
                decoded = re.sub(r'[\x00-\x1f]+', ' ', decoded).strip()
                if decoded and not _looks_garbled(decoded):
                    return decoded[:320]
                # fallback: short hex preview
                return hex_bytes[:32].hex()
            except Exception:
                return "unparsed_binary"
        if rhs.startswith('"') and rhs.endswith('"'):
            return rhs[1:-1]
        return rhs[:220]

    for line in lines:
        s = line.strip()
        if section_re.match(s):
            in_section = True
            continue
        if in_section and s.startswith('[') and 'MountedDevices' not in s:
            in_section = False
        if not in_section:
            continue

        vm = val_re.match(s)
        if not vm:
            continue
        name = vm.group(1)
        rhs = vm.group(2).strip()

        kind = "Other"
        drive_letter = ""
        low = name.lower()
        if low.startswith(r"\\dosdevices\\"):
            kind = "DriveLetter"
            drive_letter = name.split("\\")[-1]
        elif low.startswith(r"\\??\\volume{"):
            kind = "VolumeGUID"

        entries.append({
            "name": name,
            "kind": kind,
            "drive_letter": drive_letter,
            "decoded_hint": _decode_rhs(rhs),
            "raw": (rhs[:240] + ("..." if len(rhs) > 240 else "")),
        })

    return entries

def parse_reg_export_mounteddevices(text: str) -> Dict[str, str]:
    section_re = re.compile(r'^\[HKEY_LOCAL_MACHINE\\SYSTEM\\MountedDevices\]\s*$', re.I)
    val_re = re.compile(r'^"([^"]+)"=(.*)$')
    hex_re = re.compile(r'^hex(?:\([0-9a-f]+\))?:', re.I)

    in_section = False
    mapping: Dict[str, str] = {}

    lines = _reg_join_continuations(text)

    for line in lines:
        s = line.strip()
        if section_re.match(s):
            in_section = True
            continue
        if in_section and s.startswith('[') and 'MountedDevices' not in s:
            in_section = False
        if not in_section:
            continue

        vm = val_re.match(s)
        if not vm:
            continue
        name = vm.group(1)  # e.g. \\DosDevices\\E:
        rhs = vm.group(2).strip()

        norm_name = name.lstrip("\\").lower()
        if not norm_name.startswith("dosdevices\\"):
            continue

        letter = name.split("\\")[-1]
        hint = ""

        if hex_re.match(rhs):
            try:
                hex_part = rhs.split(":", 1)[1]
                hex_part = hex_part.replace("\\", "")
                hex_bytes = bytes(int(x, 16) for x in hex_part.split(",") if x.strip())
                decoded = hex_bytes.decode("utf-16-le", errors="ignore")
                decoded = re.sub(r'[\x00-\x1f]+', ' ', decoded).strip()
                # avoid showing garbled output in UI
                if decoded and sum(1 for ch in decoded if ch.isprintable()) / max(1, len(decoded)) >= 0.80 and decoded.count("\ufffd") < 2:
                    hint = decoded[:320]
                else:
                    hint = hex_bytes[:32].hex()
            except Exception:
                hint = "unparsed_binary"
        else:
            if rhs.startswith('"') and rhs.endswith('"'):
                hint = rhs[1:-1]

        mapping[letter] = hint

    return mapping


@dataclass
class SetupAPIIndex:
    """
    Index hasil parsing SetupAPI.dev.log untuk korelasi USB.

    Catatan istilah:
    - SetupAPI.dev.log tidak selalu berisi event "install / first seen".
      Ada juga section seperti "Delete Device" atau operasi lain.
    - Karena itu, metrik dan timestamp yang diambil di sini adalah:
        "earliest matched section timestamp"
      untuk device yang terdeteksi (berdasarkan serial jika ada, fallback vendor+product).
    """
    serial_first_ts: Dict[str, datetime]
    model_first_ts: Dict[str, datetime]
    matched_sections: int = 0

    def __len__(self) -> int:
        return int(self.matched_sections or 0)


def parse_setupapi_devlog(log_text: str) -> SetupAPIIndex:
    """
    Parse setupapi.dev.log dan ambil timestamp "Section start" untuk section yang
    mengandung identitas USBSTOR.

    Output:
      - serial_first_ts: mapping SERIAL (uppercase) -> earliest timestamp
      - model_first_ts : mapping "VENDOR|PRODUCT" (uppercase, underscore dipertahankan) -> earliest timestamp
      - matched_sections: jumlah section SetupAPI yang mengandung USBSTOR (unik berdasarkan header boundary)

    Kenapa ada dua index?
      1) Serial/instance_id adalah yang paling akurat.
      2) Tapi di lapangan string di SetupAPI bisa dibungkus/berbeda format, atau serial gagal
         dikaitkan ke instance_id registry. Maka ada fallback vendor+product (lebih longgar).
    """
    if not log_text:
        return SetupAPIIndex(serial_first_ts={}, model_first_ts={}, matched_sections=0)

    section_start_re = re.compile(
        r">>>\s*Section start\s+(\d{4}/\d{1,2}/\d{1,2})\s+(\d{1,2}:\d{2}:\d{2}(?:\.\d+)?)",
        re.IGNORECASE,
    )
    # Header bisa satu baris penuh, atau digabung dengan "Section start ..." dalam satu baris.
    # Juga bisa muncul setelah token lain (mis. "<<< [Exit status] >>> [Delete Device ...]").
    header_re = re.compile(r">>>\s*\[(.+?)\]", re.IGNORECASE)
    # NOTE: In setupapi.dev.log, device instance strings commonly appear as
    #   - USBSTOR\Disk&Ven_...\SERIAL&0
    # and sometimes as
    #   - ..._??_USBSTOR#DISK&VEN_...#SERIAL&0#...
    # Therefore we must match BOTH a single backslash and '#'.
    usbstor_any_re = re.compile(r"(USBSTOR(?:\\|#)[^\s\]]{5,300})", re.IGNORECASE)

    serial_first: Dict[str, datetime] = {}
    model_first: Dict[str, datetime] = {}

    current_ts: Optional[datetime] = None
    current_serials: set = set()
    current_models: set = set()
    matched_sections = 0

    def _extract_model_key(norm_upper: str) -> str:
        if not norm_upper:
            return ""
        vm = re.search(r"VEN_([^&\\]+)", norm_upper, flags=re.IGNORECASE)
        pm = re.search(r"PROD_([^&\\]+)", norm_upper, flags=re.IGNORECASE)
        if not (vm and pm):
            return ""
        return f"{vm.group(1).strip().upper()}|{pm.group(1).strip().upper()}"

    def _put_serial_variants(serial: str, ts_dt: datetime):
        serial = (serial or "").strip().upper()
        if not serial:
            return

        candidates = {serial}
        if serial.endswith("&0"):
            candidates.add(serial[:-2])
        else:
            candidates.add(serial + "&0")

        for k in candidates:
            prev = serial_first.get(k)
            if prev is None or ts_dt < prev:
                serial_first[k] = ts_dt

    def _put_model(model_key: str, ts_dt: datetime):
        model_key = (model_key or "").strip().upper()
        if not model_key or "|" not in model_key:
            return
        prev = model_first.get(model_key)
        if prev is None or ts_dt < prev:
            model_first[model_key] = ts_dt

    def _maybe_add_instance(text: str):
        nonlocal current_serials, current_models
        if not text:
            return
        norm = _normalize_instance_id(text)
        if not norm:
            return
        norm_u = norm.upper()
        if "USBSTOR" not in norm_u:
            return
        serial = _extract_usb_serial(norm_u)
        if serial:
            current_serials.add(serial.strip().upper())
        mk = _extract_model_key(norm_u)
        if mk:
            current_models.add(mk)

    def _commit_section():
        nonlocal current_ts, current_serials, current_models, matched_sections
        if current_ts is None or (not current_serials and not current_models):
            current_ts = None
            current_serials = set()
            current_models = set()
            return

        for s in list(current_serials):
            _put_serial_variants(s, current_ts)
        for mk in list(current_models):
            _put_model(mk, current_ts)

        matched_sections += 1
        current_ts = None
        current_serials = set()
        current_models = set()

    for line in log_text.splitlines():
        # 1) Header boundary (commit previous section first)
        hm = header_re.search(line)
        if hm:
            _commit_section()
            header_txt = hm.group(1)

            # Header sering berbentuk: "Device Install ... - <instance>" atau
            # "Delete Device - STORAGE\VOLUME\_??_USBSTOR#DISK&VEN_...#SERIAL..."
            _maybe_add_instance(header_txt)
            if " - " in header_txt:
                _maybe_add_instance(header_txt.split(" - ", 1)[1])

            # Jangan 'continue' — baris yang sama bisa juga memuat "Section start" dan USBSTOR.

        # 2) Timestamp (boleh satu baris dengan header)
        tm = section_start_re.search(line)
        if tm:
            dt_txt = f"{tm.group(1)} {tm.group(2)}"
            try:
                ts = pd.to_datetime(dt_txt, errors="coerce")
            except Exception:
                ts = pd.NaT
            if not pd.isna(ts):
                cand = ts.to_pydatetime()
                if current_ts is None or cand < current_ts:
                    current_ts = cand

        # 3) Harvest USBSTOR substrings dari baris apa pun (termasuk baris Section start)
        for mm in usbstor_any_re.finditer(line):
            _maybe_add_instance(mm.group(1))

    _commit_section()
    return SetupAPIIndex(serial_first_ts=serial_first, model_first_ts=model_first, matched_sections=matched_sections)


def correlate(devices: List[USBDevice], setupapi_index, mounted_map: Dict[str, str]) -> List[USBDevice]:
    """
    Attach:
      - setupapi timestamp (earliest matched section) dari SetupAPIIndex:
          * prioritas: serial/instance_id
          * fallback : vendor+product
      - drive_letters best-effort from mounted_map (letter -> hint string)
    """
    # Backward compatibility: allow passing dict (serial->ts) as before
    serial_map: Dict[str, datetime] = {}
    model_map: Dict[str, datetime] = {}
    if isinstance(setupapi_index, SetupAPIIndex):
        serial_map = setupapi_index.serial_first_ts or {}
        model_map = setupapi_index.model_first_ts or {}
    elif isinstance(setupapi_index, dict):
        serial_map = setupapi_index or {}
        model_map = {}
    else:
        serial_map = {}
        model_map = {}

    def _device_model_key(device_id: str) -> str:
        if not device_id:
            return ""
        s = str(device_id).strip().upper()
        if s.startswith("USBSTOR\\"):
            s = s.split("\\", 1)[1]
        vm = re.search(r"VEN_([^&\\]+)", s, flags=re.IGNORECASE)
        pm = re.search(r"PROD_([^&\\]+)", s, flags=re.IGNORECASE)
        if not (vm and pm):
            return ""
        return f"{vm.group(1).strip().upper()}|{pm.group(1).strip().upper()}"

    for dev in devices:
        ts = None
        match_kind = None

        serial = (dev.instance_id or "").strip().upper()
        if serial_map and serial:
            ts = serial_map.get(serial)
            # best-effort: handle common Windows suffix differences
            if ts is None and serial.endswith("&0"):
                ts = serial_map.get(serial[:-2])
            if ts is None and (not serial.endswith("&0")):
                ts = serial_map.get(serial + "&0")
            if ts is not None:
                match_kind = "serial"

        # fallback vendor+product (lebih longgar)
        if ts is None and model_map:
            mk = _device_model_key(dev.device_id)
            if mk:
                ts = model_map.get(mk)
                if ts is not None:
                    match_kind = "model"
                    dev.evidence = dev.evidence or {}
                    dev.evidence["setupapi_model_key"] = mk

        if ts is not None:
            dev.first_seen = ts
            dev.evidence = dev.evidence or {}
            dev.evidence["setupapi_match"] = match_kind or "unknown"

        # drive letter inference
        letters = []
        devkey = dev.device_id.split("\\", 1)[1] if "\\" in dev.device_id else dev.device_id
        vend = (dev.vendor or "").lower().replace(" ", "")
        prod = (dev.product or "").lower().replace(" ", "")

        for letter, hint in (mounted_map or {}).items():
            h = (hint or "").lower().replace(" ", "")
            if devkey.lower() in h or (vend and vend in h and prod and prod in h):
                letters.append(letter)

        dev.drive_letters = sorted(set(letters)) if letters else (dev.drive_letters or [])
    return devices

def _normalize_instance_id(s: str) -> str:
    """Normalize various USB instance ID formats to a comparable canonical form."""
    if s is None:
        return ""
    # Unescape XML/HTML entities (e.g., &amp;)
    try:
        s = html.unescape(str(s))
    except Exception:
        s = str(s)
    s = s.replace("\u0000", "").strip()
    # Common separators in Event Log messages / reg exports
    s = s.replace("/", "\\").replace("#", "\\")
    # Remove surrounding braces/quotes
    s = s.strip(' "\'')
    # Some messages include leading text like "Device Instance ID"
    s = re.sub(r"(?i)^device instance id[:\s]+", "", s).strip()

    # If wrapped by SWD\WPDBUSENUM\??_... keep only USBSTOR portion
    m = re.search(r"(USBSTOR\\Disk.*)", s, flags=re.IGNORECASE)
    if m:
        s = m.group(1)

    # Drop leading ??_ if present
    s = re.sub(r"^\?\?_+", "", s)

    # Normalize case on "Disk"
    s = re.sub(r"(?i)USBSTOR\\DISK", r"USBSTOR\\Disk", s)

    # Collapse multiple backslashes
    s = re.sub(r"\\{2,}", r"\\", s)

    return s

def parse_system_evtx_xml(xml_bytes: bytes):
    """
    Parse Windows Event Viewer XML export (System log) and extract USB-related events.
    Designed to work without external EVTX libraries.

    Expected input: 'Save all events as... -> XML' from Event Viewer (preferably filtered).
    Returns: DataFrame with columns: timestamp, source, event_id, instance_id, message
    """
    import pandas as pd
    import xml.etree.ElementTree as ET

    # Best-effort decode
    text = None
    for enc in ("utf-8", "utf-16", "utf-16-le", "utf-16-be", "cp1252"):
        try:
            text = xml_bytes.decode(enc)
            break
        except Exception:
            continue
    if text is None:
        text = xml_bytes.decode("utf-8", errors="ignore")

    # Strip potential BOM garbage around xml
    text = text.lstrip("\ufeff").strip()

    try:
        root = ET.fromstring(text)
    except Exception as e:
        raise ValueError(f"XML tidak valid atau bukan export Event Viewer. Detail: {e}")

    ns = {"e": "http://schemas.microsoft.com/win/2004/08/events/event"}

    rows = []
    for ev in root.findall(".//e:Event", ns):
        # System section
        provider = ev.find("./e:System/e:Provider", ns)
        source = provider.get("Name") if provider is not None else None

        event_id_el = ev.find("./e:System/e:EventID", ns)
        event_id = None
        if event_id_el is not None and event_id_el.text:
            try:
                event_id = int(event_id_el.text.strip())
            except Exception:
                event_id = None

        time_el = ev.find("./e:System/e:TimeCreated", ns)
        ts = None
        if time_el is not None:
            ts = time_el.get("SystemTime")

        # Rendered message sometimes available as RenderingInfo/Message
        msg_el = ev.find(".//e:RenderingInfo/e:Message", ns)
        message = msg_el.text if msg_el is not None else ""

        # EventData section - look for Device Instance ID or USBSTOR strings
        inst = ""
        # Search explicit data fields first
        for data in ev.findall(".//e:EventData/e:Data", ns):
            if data is None:
                continue
            name = (data.get("Name") or "").lower()
            val = (data.text or "").strip()
            if not val:
                continue
            if "instance" in name and ("id" in name or "identifier" in name):
                inst = val
                break

        # Fallback: regex search in message / whole event text for USBSTOR instance
        if not inst:
            hay = (message or "")
            m = re.search(r"(USBSTOR[\\#].{0,200}?)\s*(?:with|$)", hay, flags=re.IGNORECASE)
            if m:
                inst = m.group(1)

        # Normalize and keep only if it looks relevant
        inst_norm = _normalize_instance_id(inst)
        if "USBSTOR" not in inst_norm.upper():
            # Sometimes XML doesn't include message; try scanning event for USBSTOR occurrences
            ev_text = ET.tostring(ev, encoding="unicode", method="xml")
            m2 = re.search(r"(USBSTOR[\\#][^<\s]{10,200})", ev_text, flags=re.IGNORECASE)
            if m2:
                inst_norm = _normalize_instance_id(m2.group(1))

        if "USBSTOR" in inst_norm.upper():
            rows.append({
                "timestamp": ts,
                "source": source,
                "event_id": event_id,
                "instance_id": inst_norm,
                "instance_id_norm": inst_norm.upper(),
                "serial": _extract_usb_serial(inst_norm),
                "message": (message or "").strip()
            })

    df = pd.DataFrame(rows)
    if df.empty:
        return df

    # Convert timestamp to datetime
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce", utc=True).dt.tz_convert(None)
    df = df.dropna(subset=["timestamp"]).sort_values("timestamp")
    return df


def _extract_usb_serial(norm: str) -> str:
    """
    Best-effort to extract the USBSTOR serial/instance segment.
    Some EventLog instance IDs end with an interface GUID: ...\SERIAL&0\{GUID}
    In that case, we want SERIAL&0 (the segment before the GUID).
    """
    if not norm:
        return ""
    parts = [p for p in str(norm).split("\\") if p]
    if not parts:
        return ""
    last = parts[-1].strip().upper()
    if re.fullmatch(r"\{[0-9A-F\-]+\}", last):
        if len(parts) >= 2:
            return parts[-2].strip().upper()
        return ""
    return last


