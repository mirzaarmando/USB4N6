# USB4N6

Streamlit app untuk korelasi artefak forensik USB di Windows (USBSTOR registry + SetupAPI + Event Log + MountedDevices).

## Menjalankan

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Catatan penggunaan

- **Auto Collect (recommended)**: jalankan di Windows sebagai Administrator untuk mengumpulkan artefak standar.
- Jika input manual, minimal unggah **USBSTOR export**. Artefak lain bersifat opsional tapi memperkuat korelasi.
- Bagian **MountedDevices** disajikan ringkas untuk pembaca awam; detail raw tersedia di expander.
