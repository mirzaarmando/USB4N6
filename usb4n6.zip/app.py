
import os
import re
import streamlit as st
import pandas as pd
from datetime import datetime, time
from usbfor.parsers import (
    parse_reg_export_usbstor,
    parse_reg_export_mounteddevices,
    parse_reg_export_mounteddevices_entries,
    parse_setupapi_devlog,
    correlate,
    parse_system_evtx_xml,
)
from usbfor.utils import (
    dumps,
    auto_collect_usb_artifacts,
    is_windows,
    is_windows_admin,
    evtx_bytes_to_xml_bytes,
)

BUILD_ID = "USB4N6 • Windows USB Flash Drive Artifact Correlation (Registry + SetupAPI + Event Log)"

UI_TIMEZONE_LABEL = "WIB (UTC+07:00)"
SUSPICION_LABELS = {
    "off_hours_activity": "Aktivitas di luar jam kerja (19:00–06:00)",
    "high_event_volume": "Volume event tinggi",
    "no_eventlog_confirmation": "Tidak ada konfirmasi Event Log",
}

def _fmt_suspicion(flags) -> str:
    """Format suspicion flags untuk UI/laporan (bukan untuk ekspor data)."""
    import ast
    import pandas as _pd
    if flags is None or (isinstance(flags, float) and _pd.isna(flags)):
        return ""
    lst = None
    if isinstance(flags, list):
        lst = flags
    elif isinstance(flags, str):
        s = flags.strip()
        if s.startswith("[") and s.endswith("]"):
            try:
                v = ast.literal_eval(s)
                if isinstance(v, list):
                    lst = v
                else:
                    lst = [s]
            except Exception:
                lst = [s]
        else:
            lst = [s]
    else:
        lst = [str(flags)]
    out = []
    seen = set()
    for f in lst:
        code = str(f).strip()
        if not code:
            continue
        label = SUSPICION_LABELS.get(code, code)
        if label not in seen:
            seen.add(label)
            out.append(label)
    return ", ".join(out)


st.set_page_config(
    page_title="USB4N6 — USB Flash Drive Forensics",
    page_icon="🔎",
    layout="wide",
)

# -------------------------
# Helpers
# -------------------------
def _decode_bytes(b: bytes) -> str:
    """Decode bytes safely without mis-decoding ANSI/UTF-8 as UTF-16.

    Important: decoding arbitrary bytes as UTF-16-LE almost never raises, but it will
    turn normal ASCII text into gibberish. So we only choose UTF-16 when there is a BOM
    or a strong NUL-byte signal.
    """
    if b is None:
        return ""

    # BOM detection
    if b.startswith(b"\xff\xfe") or b.startswith(b"\xfe\xff"):
        try:
            return b.decode("utf-16")
        except Exception:
            pass
    if b.startswith(b"\xef\xbb\xbf"):
        try:
            return b.decode("utf-8-sig")
        except Exception:
            pass

    # Heuristic: many NUL bytes => likely UTF-16
    nul = b.count(b"\x00")
    if nul > max(16, len(b) // 50):  # > ~2% (or at least 16 bytes)
        for enc in ("utf-16-le", "utf-16"):
            try:
                return b.decode(enc)
            except Exception:
                pass

    # Default: treat as UTF-8/ANSI
    for enc in ("utf-8", "cp1252"):
        try:
            return b.decode(enc)
        except Exception:
            pass
    return b.decode("utf-8", errors="replace")


def _uploader_bytes(upl):
    if upl is None:
        return None
    try:
        return upl.getvalue()
    except Exception:
        return None

def _pick_bytes(uploaded, session_key: str):
    """Prefer bytes from Auto Collect; fallback to uploaded bytes."""
    if st.session_state.get(session_key) is not None:
        return st.session_state.get(session_key)
    return _uploader_bytes(uploaded)

def _safe_dt(x):
    try:
        if pd.isna(x):
            return None
        if isinstance(x, datetime):
            return x
        return pd.to_datetime(x, errors="coerce").to_pydatetime()
    except Exception:
        return None

def _device_model_key(device_row) -> str:
    """Return model key like 'DISK&VEN_...&PROD_...&REV_...' (uppercase)."""
    dev_id = str(device_row.get("device_id") or "").strip()
    if dev_id.upper().startswith("USBSTOR\\"):
        dev_id = dev_id.split("\\", 1)[1]
    return dev_id.upper()

def _normalize_serial(s: str) -> str:
    s = (s or "").strip().upper()
    return s


# Extract likely USBSTOR identities from MountedDevices decoded hints.
# Example hint: "\\??\\USBSTOR#Disk&Ven_SanDisk&Prod_Cruzer_Blade&Rev_1.00#000228...&0#{GUID}"
USBSTOR_HINT_RE = re.compile(
    r"USBSTOR#(?P<dtype>Disk|CdRom)[^#]*Ven_(?P<vendor>[^&]+)&Prod_(?P<product>[^&]+)&Rev_(?P<rev>[^#]*)#(?P<serial>[^&#{\\]+)",
    re.IGNORECASE,
)


def mounteddevices_usb_candidates(mounted_entries):
    """Return unique USBSTOR candidates inferred from MountedDevices.

    Notes:
    - MountedDevices is historical (things that were mounted) and may include old devices.
    - Presence here is not a guarantee the device is a USB flash drive; treat as "possible".
    """
    rows = []
    for e in mounted_entries or []:
        hint = str(e.get("decoded_hint") or "").strip()
        if "USBSTOR#" not in hint.upper():
            continue
        m = USBSTOR_HINT_RE.search(hint)
        if not m:
            continue
        vendor = m.group("vendor").replace("_", " ").strip()
        product = m.group("product").replace("_", " ").strip()
        rev = (m.group("rev") or "").replace("_", " ").strip() or None
        serial = (m.group("serial") or "").strip()
        rows.append(
            {
                "vendor": vendor,
                "product": product,
                "rev": rev,
                "serial": serial,
                "type": m.group("dtype"),
                "sample_hint": hint,
                "count": 1,
            }
        )

    if not rows:
        return pd.DataFrame(columns=["vendor", "product", "rev", "serial", "type", "count", "sample_hint"])

    df = pd.DataFrame(rows)
    g = (
        df.groupby(["vendor", "product", "rev", "serial", "type"], dropna=False)["count"]
        .sum()
        .reset_index()
    )
    samp = df.drop_duplicates(["vendor", "product", "rev", "serial", "type"])[
        ["vendor", "product", "rev", "serial", "type", "sample_hint"]
    ]
    out = g.merge(samp, on=["vendor", "product", "rev", "serial", "type"], how="left")
    return out.sort_values(["count", "vendor", "product"], ascending=[False, True, True])

def _matches_event(device_row, ev_df: pd.DataFrame) -> pd.DataFrame:
    """
    Robust match (best-effort):
    1) Exact: same model key + same serial
    2) Fallback: serial-only
    3) Fallback: model-only (same model, serial may differ)
    """
    if ev_df is None or ev_df.empty:
        return ev_df.iloc[0:0] if ev_df is not None else pd.DataFrame()

    model_key = _device_model_key(device_row)
    serial = _normalize_serial(str(device_row.get("instance_id") or ""))

    df = ev_df.copy()

    src = df["instance_id_norm"].astype(str) if "instance_id_norm" in df.columns else df["instance_id"].astype(str).str.upper()
    df["_event_model_key"] = src.str.extract(r"USBSTOR\\(DISK[^\\]+)", expand=False).fillna("").astype(str).str.upper()

    if "serial" in df.columns:
        df["_event_serial"] = df["serial"].fillna("").astype(str).str.upper()
    else:
        df["_event_serial"] = src.str.split("\\").str[-1].fillna("").astype(str).str.upper()

    # exact
    exact = df
    if model_key:
        exact = exact[exact["_event_model_key"] == model_key]
    if serial:
        exact = exact[exact["_event_serial"] == serial]
        if exact.empty and serial.endswith("&0"):
            exact = df[(df["_event_model_key"] == model_key) & (df["_event_serial"] == serial[:-2])]
    if not exact.empty:
        return exact.drop(columns=["_event_model_key","_event_serial"], errors="ignore")

    # serial-only
    if serial:
        msk = df["_event_serial"].str.contains(re.escape(serial), na=False)
        if serial.endswith("&0"):
            msk = msk | df["_event_serial"].str.contains(re.escape(serial[:-2]), na=False)
        out = df[msk]
        if not out.empty:
            return out.drop(columns=["_event_model_key","_event_serial"], errors="ignore")

    # model-only
    if model_key:
        out = df[df["_event_model_key"] == model_key]
        return out.drop(columns=["_event_model_key","_event_serial"], errors="ignore")

    return df.iloc[0:0]

def _related_events_same_model(device_row, ev_df: pd.DataFrame) -> pd.DataFrame:
    """Same USB model key but different serial (helps explain why Event Log can show >1 timestamp)."""
    if ev_df is None or ev_df.empty:
        return ev_df.iloc[0:0] if ev_df is not None else pd.DataFrame()
    model_key = _device_model_key(device_row)
    serial = _normalize_serial(str(device_row.get("instance_id") or ""))

    df = ev_df.copy()
    src = df["instance_id_norm"].astype(str) if "instance_id_norm" in df.columns else df["instance_id"].astype(str).str.upper()
    df["_event_model_key"] = src.str.extract(r"USBSTOR\\(DISK[^\\]+)", expand=False).fillna("").astype(str).str.upper()
    if "serial" in df.columns:
        df["_event_serial"] = df["serial"].fillna("").astype(str).str.upper()
    else:
        df["_event_serial"] = src.str.split("\\").str[-1].fillna("").astype(str).str.upper()

    rel = df[df["_event_model_key"] == model_key].copy() if model_key else df.iloc[0:0]
    if serial:
        rel = rel[rel["_event_serial"] != serial]
        if serial.endswith("&0"):
            rel = rel[rel["_event_serial"] != serial[:-2]]
    return rel.drop(columns=["_event_model_key","_event_serial"], errors="ignore")

def _score_device(row, ev_hits: pd.DataFrame) -> tuple[int, list[str]]:
    score = 40  # base: appears in USBSTOR (registry artifact)
    reasons = []
    if row.get("first_seen"):
        score += 20
        reasons.append("setupapi_first_seen")
    if row.get("drive_letters"):
        # drive_letters might be list or string
        dl = row.get("drive_letters")
        if isinstance(dl, list) and len(dl) > 0:
            score += 15
            reasons.append("drive_letter_inferred")
        elif isinstance(dl, str) and dl.strip():
            score += 15
            reasons.append("drive_letter_inferred")
    if ev_hits is not None and not ev_hits.empty:
        score += 25
        reasons.append("eventlog_match")
    score = max(0, min(100, int(score)))
    return score, reasons

def _suspicion_flags(ev_hits: pd.DataFrame) -> list[str]:
    flags = []
    if ev_hits is None or ev_hits.empty:
        flags.append("no_eventlog_confirmation")
        return flags
    # off-hours activity
    if "timestamp" not in ev_hits.columns:
        return flags
    ts = pd.to_datetime(ev_hits["timestamp"], errors="coerce")
    hours = ts.dt.hour
    if ((hours >= 19) | (hours <= 6)).any():
        flags.append("off_hours_activity")
    # too many install events in short period (rough)
    if len(ev_hits) >= 50:
        flags.append("high_event_volume")
    return flags

def _timeline_bins(ev_df: pd.DataFrame, freq: str = "H") -> pd.DataFrame:
    if ev_df is None or ev_df.empty:
        return pd.DataFrame({"timestamp": [], "count": []})
    g = ev_df.set_index("timestamp").resample(freq).size().rename("count").reset_index()
    return g

def _fmt_ts(dt) -> str:
    try:
        if dt is None or (isinstance(dt, float) and pd.isna(dt)):
            return "—"
        dt2 = pd.to_datetime(dt, errors="coerce")
        if pd.isna(dt2):
            return "—"
        if isinstance(dt2, pd.Timestamp):
            dt2 = dt2.to_pydatetime()
        return dt2.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(dt)

def _fmt_drive_letters(x) -> str:
    if x is None:
        return "—"
    if isinstance(x, list):
        return ", ".join([str(i) for i in x if str(i).strip()]) or "—"
    s = str(x).strip()
    return s if s and s != "[]" else "—"

def _mounted_driveletter_summary(entries: list[dict]) -> pd.DataFrame:
    if not entries:
        return pd.DataFrame()
    df = pd.DataFrame(entries)
    if df.empty:
        return df
    df = df[df.get("kind") == "DriveLetter"].copy() if "kind" in df.columns else df
    if df.empty:
        return df

    def classify(h: str) -> str:
        h2 = (h or "").upper()
        if "USBSTOR" in h2:
            return "USBSTOR"
        if "GLREADER" in h2 or "GENDISK" in h2 or "WPDBUSENUM" in h2:
            return "Removable/Reader"
        if "REMOVABLE" in h2 or "MASS" in h2 or "STORAGE" in h2:
            return "Removable/Storage"
        if "SCSI" in h2 or "NVME" in h2 or "ATA" in h2 or "IDE" in h2:
            return "Internal/Fixed"
        if "CDROM" in h2:
            return "CD-ROM"
        if "VIRTUAL" in h2:
            return "Virtual"
        if not h2:
            return "Unknown"
        return "Other"

    df["hint"] = df.get("decoded_hint").fillna("") if "decoded_hint" in df.columns else ""
    df["category"] = df["hint"].apply(classify)
    df["hint_short"] = df["hint"].astype(str).str.replace(r"\s+", " ", regex=True).str.slice(0, 120)
    out = (
        df.groupby("drive_letter", dropna=False)
          .agg(category=("category", lambda x: x.value_counts().index[0] if len(x) else "Unknown"),
               hint=("hint_short", lambda x: x.dropna().iloc[0] if len(x.dropna()) else ""))
          .reset_index()
    )
    out = out[out["drive_letter"].astype(str).str.len() > 0]
    # Sort like C:, D:, E: ...
    out["_sort"] = out["drive_letter"].astype(str).str.replace(":", "", regex=False)
    out = out.sort_values("_sort").drop(columns=["_sort"], errors="ignore")
    return out

# -------------------------
# Header
# -------------------------
st.title("USB4N6")
st.caption(BUILD_ID)

# Keep it clean: explanation goes to Report tab.
# -------------------------
# -------------------------
# Sidebar: Auto Collect + Uploads
# -------------------------
with st.sidebar:
    st.header("Input Artefak")

    st.subheader("⚡ Auto Collect (recommended)")
    st.caption("Auto Collect memerlukan Windows dan (disarankan) dijalankan sebagai Administrator.")
    c1, c2 = st.columns([1,1])
    with c1:
        do_collect = st.button("Auto Collect", width="stretch")
    with c2:
        st.metric("Hak admin", "Ya" if is_windows_admin() else "Tidak")

    if do_collect:
        if not is_windows():
            st.error("Auto Collect hanya tersedia di Windows.")
        else:
            out_dir = st.session_state.get("_collect_dir") or os.path.join(os.getcwd(), "_usb4n6_collected")
            st.session_state["_collect_dir"] = out_dir
            with st.spinner("Mengambil artefak (reg export + event log + setupapi)..."):
                try:
                    paths = auto_collect_usb_artifacts(out_dir)
                    st.session_state["_collect_meta"] = paths

                    # Load bytes into session (so user tidak perlu upload manual)
                    try:
                        st.session_state["auto_usbstor_bytes"] = open(paths["usbstor_reg"], "rb").read()
                    except Exception:
                        st.session_state["auto_usbstor_bytes"] = None
                    try:
                        st.session_state["auto_mounted_bytes"] = open(paths["mounted_reg"], "rb").read()
                    except Exception:
                        st.session_state["auto_mounted_bytes"] = None
                    try:
                        st.session_state["auto_setup_bytes"] = open(paths.get("setupapi_log", ""), "rb").read() if paths.get("setupapi_log") else None
                    except Exception:
                        st.session_state["auto_setup_bytes"] = None
                    try:
                        st.session_state["auto_systemxml_bytes"] = open(paths["system_xml"], "rb").read()
                    except Exception:
                        st.session_state["auto_systemxml_bytes"] = None

                    st.success("Auto Collect selesai.")
                except Exception as e:
                    st.session_state["_collect_meta"] = {"error": str(e)}
                    st.error(f"Gagal Auto Collect: {e}")

    meta = st.session_state.get("_collect_meta")
    if meta:
        with st.expander("Detail Auto Collect (debug)"):
            st.code(dumps(meta, indent=2))

    st.divider()
    st.subheader("Unggah Artefak (opsional jika Auto Collect)")

    usbstor_file = st.file_uploader("USBSTOR export (.reg/.txt)", type=["reg", "txt"], key="upl_usbstor")
    mounted_file = st.file_uploader("MountedDevices export (.reg/.txt) — opsional", type=["reg", "txt"], key="upl_mounted")
    setupapi_file = st.file_uploader("setupapi.dev.log (.log/.txt) — opsional", type=["log", "txt"], key="upl_setupapi")

    st.markdown("**Event Log (untuk timestamp):**")
    evtx_file = st.file_uploader("System USB log (.evtx) — opsional", type=["evtx"], key="upl_evtx")
    xml_file = st.file_uploader("System log XML export (.xml) — opsional", type=["xml"], key="upl_xml")

    st.caption("Sumber event log: Windows Logs → System (filter USB/PnP), lalu ekspor sebagai EVTX atau XML.")

    st.divider()
    st.subheader("Pengaturan Analisis")
    show_score = st.checkbox(
        "Tampilkan *evidence score* (0–100)",
        value=True,
        help="Skor ini bukan deteksi malware; ini sekadar *confidence* berdasarkan bukti lintas-sumber (USBSTOR/SetupAPI/MountedDevices/Event Log).",
    )
    enable_suspicion = st.checkbox(
        "Aktifkan heuristik *suspicious* (opsional)",
        value=False,
        help="Menandai pola sederhana (mis. aktivitas di luar jam kerja) berdasarkan Event Log. Cocoknya jadi fitur tambahan, bukan kesimpulan utama.",
    )
    st.session_state["_show_score"] = show_score
    st.session_state["_enable_suspicion"] = enable_suspicion

# -------------------------
# Load bytes from Auto Collect or uploads
# -------------------------
usbstor_bytes = _pick_bytes(usbstor_file, "auto_usbstor_bytes")
mounted_bytes = _pick_bytes(mounted_file, "auto_mounted_bytes")
setupapi_bytes = _pick_bytes(setupapi_file, "auto_setup_bytes")

event_xml_bytes = None
event_source = None
if st.session_state.get("auto_systemxml_bytes") is not None:
    event_xml_bytes = st.session_state.get("auto_systemxml_bytes")
    event_source = "autocollect(system_usb.xml)"
elif xml_file is not None:
    event_xml_bytes = _uploader_bytes(xml_file)
    event_source = "upload(xml)"
elif evtx_file is not None:
    try:
        event_xml_bytes = evtx_bytes_to_xml_bytes(_uploader_bytes(evtx_file))
        event_source = "upload(evtx→xml)"
    except Exception as e:
        st.sidebar.error(f"EVTX gagal dikonversi: {e}")

# -------------------------
# Parse artifacts
# -------------------------
devices = []
mounted_map = {}
mounted_entries = []
setup_index = {}
ev_df = pd.DataFrame()

# User settings (persisted)
SHOW_SCORE = bool(st.session_state.get("_show_score", True))
ENABLE_SUSPICION = bool(st.session_state.get("_enable_suspicion", False))

# Structured parse errors for better diagnostics
parse_errors: list[dict] = []

if usbstor_bytes:
    try:
        devices = parse_reg_export_usbstor(_decode_bytes(usbstor_bytes))
    except Exception as e:
        parse_errors.append({"source": "USBSTOR", "required": True, "error": str(e)})
else:
    # nothing
    pass

if mounted_bytes:
    try:
        mounted_text = _decode_bytes(mounted_bytes)
        mounted_map = parse_reg_export_mounteddevices(mounted_text)  # drive letters only
        mounted_entries = parse_reg_export_mounteddevices_entries(mounted_text)  # full transparency
    except Exception as e:
        parse_errors.append({"source": "MountedDevices", "required": False, "error": str(e)})

if setupapi_bytes:
    try:
        setup_index = parse_setupapi_devlog(_decode_bytes(setupapi_bytes))
    except Exception as e:
        parse_errors.append({"source": "SetupAPI", "required": False, "error": str(e)})

if event_xml_bytes:
    try:
        ev_df = parse_system_evtx_xml(event_xml_bytes)
    except Exception as e:
        parse_errors.append({"source": "Event Log", "required": False, "error": str(e)})
        ev_df = pd.DataFrame()

# Correlate registry-based data
if devices:
    try:
        devices = correlate(devices, setup_index, mounted_map)
    except Exception as e:
        parse_errors.append({"source": "Correlate", "required": True, "error": str(e)})

# Surface parsing status (after all steps)
required_errors = [x for x in parse_errors if x.get("required")]
optional_errors = [x for x in parse_errors if not x.get("required")]
if required_errors:
    st.error("Input wajib gagal diparse (USBSTOR/korelasi). Buka tab **Diagnostics** untuk detail.")
elif optional_errors:
    st.info("Sebagian input opsional tidak dapat diparse (mis. SetupAPI/Event Log). Analisis tetap dilanjutkan. Lihat tab **Diagnostics** untuk detail.")

# Build device dataframe
dev_df = pd.DataFrame([d.to_dict() for d in devices]) if devices else pd.DataFrame()

# Compute correlations with event log + scoring
corr_rows = []
if not dev_df.empty:
    for _, r in dev_df.iterrows():
        hits = _matches_event(r, ev_df)
        first = hits["timestamp"].min() if hits is not None and not hits.empty else None
        last = hits["timestamp"].max() if hits is not None and not hits.empty else None
        score, reasons = _score_device(r, hits)
        flags = _suspicion_flags(hits) if ENABLE_SUSPICION else []

        row_out = {
            "vendor": r.get("vendor"),
            "product": r.get("product"),
            "revision": r.get("revision"),
            "friendly_name": r.get("friendly_name"),
            "device_id": r.get("device_id"),
            "instance_id": r.get("instance_id"),
            "setupapi_matched_ts": r.get("first_seen"),
            "drive_letters": r.get("drive_letters"),
            "eventlog_hits": 0 if hits is None else int(len(hits)),
            "eventlog_first": first,
            "eventlog_last": last,
        }

        if SHOW_SCORE:
            row_out["score"] = score
            row_out["score_reasons"] = ", ".join(reasons)

        if ENABLE_SUSPICION:
            row_out["suspicion"] = ", ".join(flags) if flags else ""

        corr_rows.append(row_out)

corr_df = pd.DataFrame(corr_rows)

# Additional "possible" device identities inferred from MountedDevices.
md_candidates_df = mounteddevices_usb_candidates(mounted_entries)

# -------------------------
# UI Tabs
# -------------------------
tab_overview, tab_mounted, tab_timeline, tab_eventlog, tab_report, tab_debug = st.tabs(
    ["📌 Ringkasan", "🧷 MountedDevices", "🕒 Timeline", "🪵 Event Log", "📝 Laporan", "🛠️ Diagnostics"]
)

with tab_overview:
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("USB devices (USBSTOR)", int(len(dev_df)) if not dev_df.empty else 0)
    c2.metric("Kandidat USB (MountedDevices)", int(len(md_candidates_df)) if md_candidates_df is not None else 0)
    c3.metric("Mounted drive letters", int(len(mounted_map)) if mounted_map else 0)
    c4.metric("SetupAPI sections matched", int(getattr(setup_index, "matched_sections", len(setup_index))) if setup_index else 0)
    c5.metric("EventLog USB events", int(len(ev_df)) if ev_df is not None and not ev_df.empty else 0)

    if setup_index and corr_df is not None and not corr_df.empty and "setupapi_matched_ts" in corr_df.columns:
        matched = int(pd.to_datetime(corr_df["setupapi_matched_ts"], errors="coerce").notna().sum())
        st.caption(f"SetupAPI sections yang berhasil dipetakan ke device: {matched}/{len(corr_df)}")

    if usbstor_bytes is None:
        st.info("Jalankan **Auto Collect** atau unggah file **USBSTOR export** terlebih dahulu.")
    elif dev_df.empty:
        st.error("USBSTOR ada, tapi tidak berhasil diparse. Pastikan export benar dari `...\\Enum\\USBSTOR`.")
    else:
        st.subheader("Daftar perangkat + korelasi multi-sumber")
        if corr_df.empty:
            st.dataframe(dev_df, width="stretch", height=420)
        else:
            show_tech_cols = st.checkbox("Tampilkan kolom teknis (device_id / instance_id)", value=False)
            show_cols = [
                "vendor","product","revision","friendly_name","drive_letters",
                "setupapi_matched_ts","eventlog_first","eventlog_last","eventlog_hits",
                "score","suspicion",
                "device_id","instance_id",
            ]
            if not show_tech_cols:
                show_cols = [c for c in show_cols if c not in ("device_id","instance_id")]
            show_cols = [c for c in show_cols if c in corr_df.columns]
            df_show = corr_df[show_cols].copy()
            if "drive_letters" in df_show.columns:
                df_show["drive_letters"] = df_show["drive_letters"].apply(_fmt_drive_letters)
            if "setupapi_matched_ts" in df_show.columns:
                df_show["setupapi_matched_ts"] = df_show["setupapi_matched_ts"].apply(_fmt_ts)
            if "eventlog_first" in df_show.columns:
                df_show["eventlog_first"] = df_show["eventlog_first"].apply(_fmt_ts)
            if "eventlog_last" in df_show.columns:
                df_show["eventlog_last"] = df_show["eventlog_last"].apply(_fmt_ts)
            table_h = max(220, min(360, 44 * (min(len(df_show), 8) + 1) + 40))
            st.dataframe(df_show, width="stretch", height=table_h)

        # Additional devices inferred only from MountedDevices (historical / not fully correlated).
        if md_candidates_df is not None and len(md_candidates_df) > 0:
            confirmed_vp = set(
                (
                    (str(x.get("vendor") or "").lower(), str(x.get("product") or "").lower())
                    for x in corr_df.to_dict("records")
                )
            )
            confirmed_serials = set()
            for x in corr_df.to_dict("records"):
                inst = str(x.get("instance_id") or "")
                if "\\" in inst:
                    confirmed_serials.add(_normalize_serial(inst.split("\\")[-1]))

            md_show = md_candidates_df.copy()
            md_show["status"] = md_show.apply(
                lambda rr: (
                    "Terkonfirmasi (USBSTOR)"
                    if (
                        (str(rr.get("vendor") or "").lower(), str(rr.get("product") or "").lower()) in confirmed_vp
                        or _normalize_serial(str(rr.get("serial") or "")) in confirmed_serials
                    )
                    else "Terindikasi (MountedDevices)"
                ),
                axis=1,
            )
            extra = md_show[md_show["status"] == "Terindikasi (MountedDevices)"]

            st.markdown("---")
            st.subheader("Perangkat lain yang terindikasi")
            st.caption(
                "Sumber: MountedDevices (riwayat volume/drive). Ini sering memuat jejak historis; "
                "jangan diperlakukan sebagai bukti perangkat sedang tercolok tanpa konfirmasi artefak lain."
            )
            if len(extra) == 0:
                st.info("Tidak ada kandidat tambahan dari MountedDevices (di luar yang sudah terkonfirmasi USBSTOR).")
            else:
                extra = extra.copy()
                extra["serial (awal)"] = extra["serial"].astype(str).str.slice(0, 24)
                st.dataframe(
                    extra[["vendor", "product", "type", "serial (awal)", "count"]].rename(
                        columns={"count": "kemunculan"}
                    ),
                    width="stretch",
                    height=260,
                    hide_index=True,
                )
                with st.expander("Lihat detail hint (teknis)", expanded=False):
                    st.dataframe(
                        extra[["vendor", "product", "type", "serial", "rev", "count", "sample_hint"]],
                        width="stretch",
                        height=420,
                        hide_index=True,
                    )

        
        with st.expander("Catatan (posisi USB4N6 vs tools umum)", expanded=False):
            st.markdown("""
- USB4N6 berfokus pada forensik USB: mengkorelasi artefak registry dan log agar bukti lebih mudah disusun dalam laporan.
- Tools umum (FTK/Autopsy) bersifat general-purpose; USB4N6 menekankan **korelasi + timeline + evidence** untuk kasus USB flash drive.
- Output disajikan untuk laporan: tabel evidence, timeline, dan ekspor data.
""")

with tab_mounted:
    st.subheader("MountedDevices")

    st.markdown(
        "MountedDevices menyimpan mapping **volume/disk → drive letter** yang pernah muncul di sistem. "
        "Artefak ini berguna untuk melihat **huruf drive** dan **jejak volume** yang pernah digunakan. "
        "Namun, korelasi ke 1 perangkat USB tertentu tidak selalu bisa dilakukan tanpa artefak tambahan."
    )

    if not mounted_entries:
        st.info("Belum ada data MountedDevices. Unggah/export MountedDevices atau jalankan Auto Collect.")
    else:
        # Friendly summary for non-experts
        summary = _mounted_driveletter_summary(mounted_entries)
        if summary.empty:
            st.warning("MountedDevices terbaca, tapi tidak ada entry DriveLetter yang bisa diringkas.")
        else:
            st.markdown("### Drive letters yang teramati")
            st.dataframe(summary, width="stretch", height=260)

            st.caption(
                "Kategori 'USBSTOR' berarti decoded_hint memuat string USBSTOR (indikasi kuat perangkat storage via USB). "
                "Kategori lain bersifat indikatif dan dapat mencakup volume internal/virtual/optical atau device lain."
            )

        # Advanced view (raw)
        with st.expander("Lihat detail lanjutan (raw MountedDevices)", expanded=False):
            dfm = pd.DataFrame(mounted_entries)
            if not dfm.empty and "kind" in dfm.columns:
                counts = dfm["kind"].value_counts().rename_axis("kind").reset_index(name="count")
                st.dataframe(counts, width="stretch", height=160)

            show_cols = ["kind", "drive_letter", "name", "decoded_hint", "raw"]
            show_cols = [c for c in show_cols if c in dfm.columns]
            # Small cleanup: keep decoded_hint short
            if "decoded_hint" in dfm.columns:
                dfm["decoded_hint"] = dfm["decoded_hint"].fillna("").astype(str).str.slice(0, 260)
            st.dataframe(dfm[show_cols], width="stretch", height=520)

            st.download_button(
                "Download MountedDevices (raw CSV)",
                data=dfm[show_cols].to_csv(index=False).encode("utf-8"),
                file_name="usb4n6_mounteddevices_raw.csv",
                mime="text/csv",
            )

        st.caption(
            "Catatan: pemetaan drive letter → device bisa diperkuat dengan artefak lain (mis. MountPoints2 / ShellBags / UserAssist), "
            "jika tersedia."
        )

with tab_timeline:
    st.subheader("Timeline per device")

    if corr_df.empty:
        st.info("Timeline membutuhkan minimal USBSTOR dan (ideal) Event Log.")
    elif ev_df is None or ev_df.empty:
        st.warning("Event Log belum tersedia atau tidak terbaca. Unggah **System.evtx/XML** atau jalankan Auto Collect.")
    else:
        corr_df["_label"] = corr_df.apply(
            lambda r: f"{r.get('vendor','?')} | {r.get('product','?')} | {r.get('instance_id','')}",
            axis=1,
        )
        pick = st.selectbox("Pilih device", corr_df["_label"].tolist(), index=0)
        row = corr_df[corr_df["_label"] == pick].iloc[0].to_dict()

        exact = _matches_event(row, ev_df)
        related = _related_events_same_model(row, ev_df)

        c1, c2, c3 = st.columns(3)
        c1.metric("Matched events", int(len(exact)) if exact is not None else 0)
        c2.metric("Related events (same model)", int(len(related)) if related is not None else 0)
        if exact is not None and not exact.empty:
            c3.metric("Matched time range", f"{_fmt_ts(exact['timestamp'].min())} → {_fmt_ts(exact['timestamp'].max())}")
        else:
            c3.metric("Matched time range", "—")

        if exact is None or exact.empty:
            st.info(
                "Tidak ada event yang *exact match* untuk serial ini di Event Log. "
                "Jika perangkat benar-benar pernah aktif, kemungkinan log tidak ada / tidak diekspor / format instance-id berbeda. "
                "Cek bagian **Related events** (vendor+product sama)."
            )
        else:
            st.markdown("#### Aktivitas (Event Log)")
            plot_df = exact.copy().sort_values("timestamp")
            span = plot_df["timestamp"].max() - plot_df["timestamp"].min()
            freq = "H" if span <= pd.Timedelta(days=2) else "D"
            bins = _timeline_bins(plot_df, freq=freq)
            bins = bins.rename(columns={"count": "events"})
            try:
                import plotly.express as px

                fig = px.bar(bins, x="timestamp", y="events", height=260)
                fig.update_layout(margin=dict(l=10, r=10, t=10, b=10), showlegend=False)
                st.plotly_chart(fig, use_container_width=True)
            except Exception:
                st.bar_chart(bins.set_index("timestamp")["events"])

            with st.expander("Lihat event detail (matched)", expanded=False):
                show = exact.copy().sort_values("timestamp")
                show["timestamp"] = show["timestamp"].astype(str)
                show_cols = ["timestamp", "source", "event_id", "serial", "instance_id", "message"]
                show_cols = [c for c in show_cols if c in show.columns]
                st.dataframe(show[show_cols], width="stretch", height=420)

        if related is not None and not related.empty:
            with st.expander("Related events (same model, different serial)", expanded=False):
                show2 = related.copy().sort_values("timestamp")
                show2["timestamp"] = show2["timestamp"].astype(str)
                show_cols2 = ["timestamp","source","event_id","serial","instance_id","message"]
                show_cols2 = [c for c in show_cols2 if c in show2.columns]
                st.dataframe(show2[show_cols2], width="stretch", height=420)

with tab_eventlog:

    st.subheader("Event Log (USB-related) — untuk korelasi timestamp")
    if event_xml_bytes is None and (evtx_file is None and xml_file is None):
        st.info("Upload **System.evtx** atau **XML export** (atau pakai Auto Collect) untuk lihat event.")
    if ev_df is None or ev_df.empty:
        st.warning("Belum ada event USB yang terbaca. Kemungkinan:\n- Log belum difilter\n- EVTX gagal dikonversi\n- Sistem nggak punya event terkait USB\n\nCek tab Debug untuk error.")
    else:
        st.caption(f"Sumber: **{event_source}**" if event_source else "")
        st.dataframe(ev_df, width="stretch", height=520)

with tab_report:
    st.subheader("Ringkasan Investigasi")
    if corr_df.empty:
        st.info("Belum ada data. Minimal diperlukan USBSTOR.")
    else:
        # Simple report text
        if SHOW_SCORE and "score" in corr_df.columns:
            top = corr_df.sort_values("score", ascending=False).head(10)
        else:
            top = corr_df.sort_values("eventlog_hits", ascending=False).head(10)
        n_devices = len(corr_df)
        n_confirmed = int((corr_df["eventlog_hits"] > 0).sum()) if "eventlog_hits" in corr_df.columns else 0

        confirmed_vp = set(
            (
                (str(x.get("vendor") or "").lower(), str(x.get("product") or "").lower())
                for x in corr_df.to_dict("records")
            )
        )
        confirmed_serials = set()
        for x in corr_df.to_dict("records"):
            inst = str(x.get("instance_id") or "")
            if "\\" in inst:
                confirmed_serials.add(_normalize_serial(inst.split("\\")[-1]))

        extra_md = pd.DataFrame()
        if md_candidates_df is not None and len(md_candidates_df) > 0:
            tmp = md_candidates_df.copy()
            tmp["is_confirmed"] = tmp.apply(
                lambda rr: (
                    (str(rr.get("vendor") or "").lower(), str(rr.get("product") or "").lower()) in confirmed_vp
                    or _normalize_serial(str(rr.get("serial") or "")) in confirmed_serials
                ),
                axis=1,
            )
            extra_md = tmp[tmp["is_confirmed"] == False]
        n_extra_md = int(len(extra_md)) if extra_md is not None and not extra_md.empty else 0
        report_md = f"""
- Perangkat USB terdeteksi (USBSTOR): **{n_devices}**
- Perangkat dengan konfirmasi Event Log: **{n_confirmed}**
- Kandidat tambahan dari MountedDevices (belum terkorelasi): **{n_extra_md}**
- Sumber: **Registry USBSTOR**, **MountedDevices (opsional)**, **SetupAPI (opsional)**, **System Event Log (opsional)**

### Perangkat Terkonfirmasi (Top)
"""
        for _, r in top.iterrows():
            score_part = f"score **{r.get('score','')}**; " if (SHOW_SCORE and "score" in corr_df.columns) else ""
            susp_part = ''
            if ENABLE_SUSPICION and 'suspicion' in corr_df.columns:
                _s = _fmt_suspicion(r.get('suspicion',''))
                if _s:
                    susp_part = f"indikasi: {_s}"

            report_md += (
                f"- **{r.get('vendor','?')} {r.get('product','?')}** "
                f"(instance: `{r.get('instance_id','')}`) — "
                f"{score_part}"
                f"hits **{r.get('eventlog_hits','0')}**; "
                f"setupapi matched: `{r.get('setupapi_matched_ts','')}`; "
                f"eventlog first: `{r.get('eventlog_first','')}`"
                + (f"; {susp_part}" if susp_part else "")
                + "\n"
            )

        st.markdown(report_md)

        if n_extra_md > 0:
            st.markdown("### Perangkat Terindikasi (MountedDevices)")
            st.caption(
                "Daftar ini berasal dari string USBSTOR di MountedDevices dan bersifat historis/indikatif. "
                "Gunakan sebagai petunjuk awal, bukan konfirmasi final."
            )
            show = extra_md.copy()
            show["serial (awal)"] = show["serial"].astype(str).str.slice(0, 24)
            st.dataframe(
                show[["vendor", "product", "type", "serial (awal)", "count"]].rename(columns={"count": "kemunculan"}),
                width="stretch",
                height=260,
                hide_index=True,
            )

        with st.expander("Cara kerja score & heuristik", expanded=False):
            st.markdown(
                """
**Evidence score (0–100)** adalah *confidence score* sederhana untuk mengurutkan perangkat berdasarkan kekuatan bukti lintas-sumber.

- Base **40**: device terdeteksi dari **USBSTOR** (Registry)
- **+20**: ada section **SetupAPI** yang match ke device
- **+15**: drive letter berhasil diinfer dari **MountedDevices**
- **+25**: ada kecocokan **Event Log** (USB/PnP)

Skor ini **bukan** deteksi ancaman; tujuan utamanya mempermudah prioritas pemeriksaan.

Jika opsi **heuristik suspicious** diaktifkan, USB4N6 menambahkan penanda sederhana:
- **Aktivitas di luar jam kerja (19:00–06:00)**: ada event antara **19:00–06:00** (berdasarkan WIB (UTC+07:00))
- **Volume event tinggi**: jumlah event untuk device sangat banyak (indikasi kasar)
- **Tidak ada konfirmasi Event Log**: device terdeteksi dari registry tetapi tidak ada event log yang cocok
"""
            )

        st.markdown("### Download output")
        # Export CSV + JSON
        out_csv = corr_df.drop(columns=["_label"], errors="ignore").to_csv(index=False).encode("utf-8")
        out_json = dumps(corr_df.drop(columns=["_label"], errors="ignore").to_dict(orient="records"), indent=2).encode("utf-8")
        st.download_button("Download CSV (korelasi)", data=out_csv, file_name="usb4n6_correlation.csv", mime="text/csv")
        st.download_button("Download JSON (korelasi)", data=out_json, file_name="usb4n6_correlation.json", mime="application/json")

with tab_debug:
    st.subheader("Diagnostics")
    st.caption("Menampilkan error parsing dan ringkasan input untuk membantu troubleshooting.")

    if parse_errors:
        st.error("Error/Warning parsing:")
        lines = []
        for e in parse_errors:
            src = e.get("source", "?")
            req = "REQUIRED" if e.get("required") else "optional"
            msg = e.get("error", "")
            lines.append(f"[{req}] {src}: {msg}")
        st.code("\n".join(lines))
    else:
        st.success("Tidak ada error parsing yang terdeteksi.")

    with st.expander("Ringkasan sumber data", expanded=False):
        st.code(dumps({
            "has_usbstor": bool(usbstor_bytes),
            "has_mounted": bool(mounted_bytes),
            "has_setupapi": bool(setupapi_bytes),
            "setupapi_bytes_len": int(len(setupapi_bytes)) if setupapi_bytes else 0,
            "setupapi_contains_usbstor_bytes": bool(setupapi_bytes and (b"USBSTOR" in setupapi_bytes.upper())),
            "has_eventlog": bool(event_xml_bytes),
            "devices_parsed": int(len(dev_df)) if not dev_df.empty else 0,
            "mounted_values": int(len(mounted_entries)) if mounted_entries else 0,
            "setupapi_sections_matched": int(getattr(setup_index, "matched_sections", len(setup_index))) if setup_index else 0,
            "eventlog_rows": int(len(ev_df)) if ev_df is not None and not ev_df.empty else 0,
            "eventlog_source": event_source,
        }, indent=2))